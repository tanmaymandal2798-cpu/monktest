# db.py
import pyodbc

# SQL Server Configuration
DB_CONFIG = {
    'server': 'localhost',  # Your SQL Server instance
    'database': 'storedb',  # Your database name
    'username': 'storedb',  # Your SQL Server username
    'password': 'storedb',  # Your SQL Server password
    'driver': '{ODBC Driver 17 for SQL Server}'
}

def get_db_connection():
    """Create and return database connection"""
    conn_str = f"""
    DRIVER={DB_CONFIG['driver']};
    SERVER={DB_CONFIG['server']};
    DATABASE={DB_CONFIG['database']};
    UID={DB_CONFIG['username']};
    PWD={DB_CONFIG['password']};
    """
    return pyodbc.connect(conn_str)

from flask import Flask, request, jsonify
from db import get_db_connection
import json
import math

app = Flask(__name__)

# Utility: calculate total price of cart
def cart_total(cart):
    total = 0.0
    for item in cart.get("items", []):
        total += float(item["price"]) * int(item["quantity"])
    return total


def find_item(cart, product_id):
    for item in cart.get("items", []):
        if int(item["product_id"]) == int(product_id):
            return item
    return None


# --- Coupon calculation helpers ---

def calculate_cartwise_discount(details, condition, cart):
    """10% off if total cart > threshold"""
    discount_pct = float(details.get("discount_percent", 0))
    threshold = float(condition.get("min_cart_value", 0))
    total = cart_total(cart)
    if total > threshold:
        discount = round(total * (discount_pct / 100), 2)
        return discount, True
    return 0.0, False


def calculate_productwise_discount(details, condition, cart):
    """Discount for specific product"""
    product_id = details.get("product_id")
    discount_pct = float(details.get("discount_percent", 0))
    item = find_item(cart, product_id)
    if item:
        discount = round(float(item["price"]) * int(item["quantity"]) * (discount_pct / 100), 2)
        return discount, True
    return 0.0, False


def calculate_bxgy_discount(details, condition, cart):
    """Buy X get Y free"""
    buy_list = details.get("buy_products", [])
    get_list = details.get("get_products", [])
    repetition_limit = int(details.get("repetition_limit", 1))

    total_sets = 0
    for b in buy_list:
        item = find_item(cart, b["product_id"])
        if item:
            total_sets += int(item["quantity"]) // int(b["quantity"])

    total_sets = min(total_sets, repetition_limit)
    if total_sets == 0:
        return 0.0, False, {}

    total_discount = 0.0
    free_items = []
    for g in get_list:
        free_item = find_item(cart, g["product_id"])
        if free_item:
            free_qty = min(int(free_item["quantity"]), total_sets * int(g["quantity"]))
            total_discount += free_qty * float(free_item["price"])
            free_items.append({"product_id": g["product_id"], "free_qty": free_qty})

    if total_discount > 0:
        return round(total_discount, 2), True, {"free_items": free_items}
    return 0.0, False, {}


# --- CRUD APIs ---

@app.route('/coupons', methods=['POST'])
def create_coupon():
    data = request.get_json()
    ctype = data.get('type')
    discountdetails = json.dumps(data.get('discountdetails'))
    condition = json.dumps(data.get('condition'))

    conn = get_db_connection()
    cursor = conn.cursor()

    # Use OUTPUT INSERTED.ID to return auto-generated ID
    cursor.execute("""
        INSERT INTO coupons (type, discountdetails, condition)
        OUTPUT INSERTED.ID
        VALUES (?, ?, ?)
    """, (ctype, discountdetails, condition))

    # Fetch generated ID directly from the OUTPUT result
    coupon_id = cursor.fetchone()[0]
    conn.commit()

    cursor.close()
    conn.close()

    return jsonify({
        "ID": int(coupon_id),
        "type": ctype,
        "discountdetails": data.get('discountdetails'),
        "condition": data.get('condition')
    }), 201


@app.route('/coupons', methods=['GET'])
def list_coupons():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT ID, type, discountdetails, condition FROM coupons")
    rows = cursor.fetchall()
    cursor.close()
    conn.close()

    coupons = []
    for row in rows:
        coupons.append({
            "ID": row[0],
            "type": row[1],
            "discountdetails": json.loads(row[2]),
            "condition": json.loads(row[3])
        })

    return jsonify(coupons), 200


@app.route('/coupons/<int:coupon_id>', methods=['GET'])
def get_coupon(coupon_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT ID, type, discountdetails, condition FROM coupons WHERE ID = ?", (coupon_id,))
    row = cursor.fetchone()
    cursor.close()
    conn.close()

    if not row:
        return jsonify({"error": "Coupon not found"}), 404

    return jsonify({
        "ID": row[0],
        "type": row[1],
        "discountdetails": json.loads(row[2]),
        "condition": json.loads(row[3])
    })


@app.route('/coupons/<int:coupon_id>', methods=['PUT'])
def update_coupon(coupon_id):
    data = request.get_json()
    ctype = data.get('type')
    discountdetails = json.dumps(data.get('discountdetails'))
    condition = json.dumps(data.get('condition'))

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        UPDATE coupons
        SET type = ?, discountdetails = ?, condition = ?
        WHERE ID = ?
    """, (ctype, discountdetails, condition, coupon_id))
    conn.commit()
    cursor.close()
    conn.close()

    return jsonify({"message": "Coupon updated successfully", "ID": coupon_id}), 200


@app.route('/coupons/<int:coupon_id>', methods=['DELETE'])
def delete_coupon(coupon_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM coupons WHERE ID = ?", (coupon_id,))
    conn.commit()
    cursor.close()
    conn.close()
    return jsonify({"message": "Coupon deleted successfully"}), 200


# --- POST /applicable-coupons ---
@app.route('/applicable-coupons', methods=['POST'])
def get_applicable_coupons():
    payload = request.get_json()
    cart = payload.get("cart", {})

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT ID, type, discountdetails, condition FROM coupons")
    rows = cursor.fetchall()
    cursor.close()
    conn.close()

    applicable = []
    for row in rows:
        cid, ctype, dd, cond = row
        details = json.loads(dd)
        condition = json.loads(cond)

        if ctype == "cart-wise":
            discount, ok = calculate_cartwise_discount(details, condition, cart)
        elif ctype == "product-wise":
            discount, ok = calculate_productwise_discount(details, condition, cart)
        elif ctype == "bxgy":
            discount, ok, _ = calculate_bxgy_discount(details, condition, cart)
        else:
            discount, ok = 0.0, False

        if ok:
            applicable.append({
                "ID": cid,
                "type": ctype,
                "discount": discount
            })

    return jsonify({"applicable_coupons": applicable}), 200


# --- POST /apply-coupon/{id} ---
@app.route('/apply-coupon/<int:coupon_id>', methods=['POST'])
def apply_coupon(coupon_id):
    payload = request.get_json()
    cart = payload.get("cart", {})

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT type, discountdetails, condition FROM coupons WHERE ID = ?", (coupon_id,))
    row = cursor.fetchone()
    cursor.close()
    conn.close()

    if not row:
        return jsonify({"error": "Coupon not found"}), 404
    

    ctype, dd, cond = row
    details = json.loads(dd)
    condition = json.loads(cond)

    updated_cart = {"items": [], "total_price": 0.0, "total_discount": 0.0, "final_price": 0.0}
    total_price = cart_total(cart)
    updated_cart["total_price"] = round(total_price, 2)

    total_discount = 0.0

    if ctype == "cart-wise":
        discount, ok = calculate_cartwise_discount(details, condition, cart)
        if not ok:
            return jsonify({"error": "Coupon not applicable"}), 400
        total_discount = discount
        # distribute proportionally
        for item in cart["items"]:
            proportion = (item["price"] * item["quantity"]) / total_price
            item_discount = round(discount * proportion, 2)
            updated_cart["items"].append({
                **item,
                "item_discount": item_discount
            })

    elif ctype == "product-wise":
        discount, ok = calculate_productwise_discount(details, condition, cart)
        if not ok:
            return jsonify({"error": "Coupon not applicable"}), 400
        total_discount = discount
        for item in cart["items"]:
            item_discount = 0.0
            if int(item["product_id"]) == int(details["product_id"]):
                item_discount = round(discount, 2)
            updated_cart["items"].append({
                **item,
                "item_discount": item_discount
            })

    elif ctype == "bxgy":
        discount, ok, meta = calculate_bxgy_discount(details, condition, cart)
        if not ok:
            return jsonify({"error": "Coupon not applicable"}), 400
        total_discount = discount
        free_items = {f["product_id"]: f["free_qty"] for f in meta.get("free_items", [])}
        for item in cart["items"]:
            item_discount = 0.0
            if int(item["product_id"]) in free_items:
                item_discount = round(free_items[item["product_id"]] * item["price"], 2)
                item["quantity"] += free_items[item["product_id"]]
            updated_cart["items"].append({
                **item,
                "item_discount": item_discount
            })

    updated_cart["total_discount"] = round(total_discount, 2)
    updated_cart["final_price"] = round(total_price - total_discount, 2)

    return jsonify({"updated_cart": updated_cart}), 200


if __name__ == '__main__':
    app.run(debug=True)